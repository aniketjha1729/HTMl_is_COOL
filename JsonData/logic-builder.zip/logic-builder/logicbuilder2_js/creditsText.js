var creditsArr = [
    {"name":"Name1","pos":["Idea, Conception, Level Design and Development"]},
    {"name":"Name2","pos":["Lead Development, Level Design"]},
    {"name":"Name3","pos":["Conception, Level Design and Development"]},
    {"name":"Name4","pos":["Level Design and Development"]},
    {"name":"Name5","pos":["Charlotte Breton Schreiner","Charlotte Breton Schreiner","Charlotte Breton Schreiner","Charlotte Breton Schreiner","Charlotte Breton Schreiner"]},
    {"name":"Name6","pos":["Level Design and Development"]}
]